function z = ObjectFunction(x, I_alpha, I_beta, U_alpha, U_beta)
    

    % Последовательность переменных (Rs Ls' Lm Rr Lr' J)

    %Полная мощность потребляемая АД

    P_exp = 3 * (I_alpha/sqrt(2) .* U_alpha/sqrt(2) + (I_beta/sqrt(2) .* U_beta/sqrt(2)));
    Q_exp = 3 * (I_alpha/sqrt(2) .* U_beta/sqrt(2) - (I_beta/sqrt(2) .* U_alpha/sqrt(2)));
    S_exp = sqrt(P_exp.^2 + Q_exp.^2);
    S_exp = S_exp';

    % Получаем отклик модели объекта

    % Последовательность переменных (Rs Ls' Lm Rr Lr' J)

    %Расчетные параметры
        [m, n]=size(U_alpha);
        n = n-1;
        dt = 1/1000;
        h = 1/1000;

        p = 2;
        zp = p/2;

        Rs = x(1);
        Ls = x(2) + x(3);
        Lm = x(3);
        Rr = x(4);
        Lr = x(2) + x(3);
        J = x(5);

        %Расчет параметров имитационной модели АД
        Kr=Lm/Lr;
        Re=Rs+Rr*Kr*Kr;
        Le= Ls-Lm*Lm/Lr;
        Ar=Rr/Lr;
        Km=1.5*Kr*zp;
  
    % Последовательность переменных (Rs Ls' Lm Rr Lr' J)     

    %Инициализации переменных для двухфазной модели
        t = zeros (1, n);
        Us_a = zeros (1, n);
        Us_b = zeros (1, n);
        is_a = zeros (1, n);
        is_b = zeros (1, n);
        psi_a = zeros (1, n);
        psi_b = zeros (1, n);
        speed = zeros (1, n);
        w = zeros (1, n);
        Torque = zeros (1, n);

    for i=1:n

        t(i+1) = t(i)+dt;

        %Преобразование из трехфазной системы координат в двухфазную
        Us_a(i)=U_alpha(i);
        Us_b(i)=U_beta(i);

        %Расчет двухфазной модели
        is_a(i+1)=is_a(i)+(h/Le)*(Us_a(i)-Re*is_a(i)+Kr*Ar*psi_a(i)+Kr*zp*speed(i)*psi_b(i));
        is_b(i+1)=is_b(i)+(h/Le)*(Us_b(i)-Re*is_b(i)+Kr*Ar*psi_b(i)-Kr*zp*speed(i)*psi_a(i));

        psi_a(i+1)=psi_a(i)+h*(Rr*Kr*is_a(i)-Ar*psi_a(i)-zp*speed(i)*psi_b(i));
        psi_b(i+1)=psi_b(i)+h*(Rr*Kr*is_b(i)-Ar*psi_b(i)+zp*speed(i)*psi_a(i));

        Torque(i+1)=Km*(psi_a(i)*is_b(i)-psi_b(i)*is_a(i));
        speed(i+1)=speed(i)+h/J*(Torque(i)-0);

    end


    % Вычисляем потребляемую мощность модели объекта исследования

    P_ras = 3 * (is_a/sqrt(2) .* U_alpha/sqrt(2) + (is_b/sqrt(2) .* U_beta/sqrt(2)));
    Q_ras = 3 * (is_a/sqrt(2) .* U_beta/sqrt(2) - (is_b/sqrt(2) .* U_alpha/sqrt(2)));
    S_ras = sqrt(P_ras.^2 + Q_ras.^2);
    S_ras = S_ras';

    
    % Задаем переменные

    z = (sum(S_exp(1200:1500)-S_ras(1200:1500)).^2 + sum(S_exp(2500:3000)-S_ras(2500:3000)).^2);

end