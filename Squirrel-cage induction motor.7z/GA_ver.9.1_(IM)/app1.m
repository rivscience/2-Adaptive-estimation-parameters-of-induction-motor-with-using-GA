clc;
clear;
close all;
%% Загрузка данных

load('D:\Google Disk\2 Наука\1 Статьи\3 Генетический алгоритм\GA_ver.9.1_(IM)\Data_[U, I, w]_a=60_xx.mat');

%%  Целевая функция

problem.CostFunction = @(x) ObjectFunction(x, I_alpha, I_beta, U_alpha, U_beta);  % Целевая функция
problem.nVar = 5;                               % Количество генов (Переменных)

problem.VarMin = [0.1   0.001   0.01    0.1     0.0001  ];                      % Минимальные пределы переменных (Rs Ls' Lm Rr Lr' J)
problem.VarMax = [50    0.2     2       50      0.1     ];                        % Максимальные пределы переменных (Rs Ls' Lm Rr Lr' J) 

%%  Параметры генетического алгоритма

params.MaxIt = 200;             % Максимальное количество итераций
params.nPop = 50;              % Количество особей

params.beta = 1.4;              % Коэффициент вероятности отбора
params.pC = 4;                  % Количество потомков
params.gamma = 0.001;           % Коффициент приращения при работе отбора
params.mu = 0.05;               % Вероятность мутации
params.sigma = 0.001;            % Шаг для добавления к родителю при мутации

%% Запуск генетического алгоритма

out = RunGA(problem, params);


%%  Результаты

run('D:\Google Disk\2 Наука\1 Статьи\3 Генетический алгоритм\GA_ver.9.1_(IM)\IM_3_phase\Parametrs.m');
run('D:\Google Disk\2 Наука\1 Статьи\3 Генетический алгоритм\GA_ver.9.1_(IM)\IM_3_phase\Main.m');
