%Расчетные параметры
[m, n]=size(U_alpha);
n = n-1;
dt = 1/1000;
h = 1/1000;

p = 2;
zp = p/2;

Rs = x(1);
Ls = x(2) + x(3);
Lm = x(3);
Rr = x(4);
Lr = x(2) + x(3);
J = x(5);

%Расчет параметров имитационной модели АД
Kr=Lm/Lr;
Re=Rs+Rr*Kr*Kr;
Le= Ls-Lm*Lm/Lr;
Ar=Rr/Lr;
Km=1.5*Kr*zp;

% Последовательность переменных (Rs Ls' Lm Rr Lr' J)     

%Инициализации переменных для двухфазной модели
t = zeros (1, n);
Us_a = zeros (1, n);
Us_b = zeros (1, n);
is_a = zeros (1, n);
is_b = zeros (1, n);
psi_a = zeros (1, n);
psi_b = zeros (1, n);
speed = zeros (1, n);
w = zeros (1, n);
Torque = zeros (1, n);