function z = ObjectFunction1(x, U_a, U_b, U_c, I_a, I_b, I_c)

      
    f = 50.02;
    t = [0 : 1/3204 : 1];


    P_exp = 3 * (((I_a/sqrt(2)) .* (U_a/sqrt(2))) + (((I_b - I_c)/sqrt(2)/sqrt(3)) .* ((U_b - U_c)/sqrt(2)/sqrt(3))));
    Q_exp = -3 * (((I_a/sqrt(2)) .* ((U_b - U_c)/sqrt(2)/sqrt(3))) - (((I_b - I_c)/sqrt(2)/sqrt(3)) .* (U_a/sqrt(2))));
    S_exp = sqrt(P_exp.^2 + Q_exp.^2);
    P_exp = P_exp';
    Q_exp = Q_exp';
    S_exp = S_exp';
  
    % Получаем отклик модели объекта

    I_aa = (U_a * cos(atan((2*pi*f*(x(2)))/x(1))) - (U_a / sin(2*pi*f*t+0-pi/2)) * cos(2*pi*f*t+0-pi/2) * sin(atan((2*pi*f*(x(2)))/x(1)))) / sqrt(x(1)^2 + (2 * pi * f * (x(2)))^2);
    I_bb = (U_b * cos(atan((2*pi*f*(x(2)))/x(1))) - (U_b / sin(2*pi*f*t+2*pi/3-pi/2)) * cos(2*pi*f*t+2*pi/3-pi/2) * sin(atan((2*pi*f*(x(2)))/x(1)))) / sqrt(x(1)^2 + (2 * pi * f * (x(2)))^2);
    I_cc = (U_c * cos(atan((2*pi*f*(x(2)))/x(1))) - (U_c / sin(2*pi*f*t-2*pi/3-pi/2)) * cos(2*pi*f*t-2*pi/3-pi/2) * sin(atan((2*pi*f*(x(2)))/x(1)))) / sqrt(x(1)^2 + (2 * pi * f * (x(2)))^2);
    

    % Вычисляем потребляемую мощность модели объекта исследования

    P_ras = 3 * (((I_aa/sqrt(2)) .* (U_a/sqrt(2))) + (((I_bb - I_cc)/sqrt(2)/sqrt(3)) .* ((U_b - U_c)/sqrt(2)/sqrt(3))));
    Q_ras = -3 * (((I_aa/sqrt(2)) .* ((U_b - U_c)/sqrt(2)/sqrt(3))) - (((I_bb - I_cc)/sqrt(2)/sqrt(3)) .* (U_a/sqrt(2))));
    S_ras = sqrt(P_ras.^2 + Q_ras.^2);
    P_ras = P_ras';
    Q_ras = Q_ras';
    S_ras = S_ras';
    
    % Задаем переменные
    z = (sum(S_exp-S_ras).^2);
    
end