clc;
clear;
close all;
%% Загрузка данных

load('C:\Users\Ivan\Downloads\2-Experimental-research-method-of-adaptive-estimation-parameters-of-induction-motor-with-using-GA-main\Data [U, I] 4.9 A.mat')


%%  Целевая функция

problem.CostFunction = @(x) ObjectFunction1(x, U_a, U_b, U_c, I_a, I_b, I_c);  % Целевая функция
problem.nVar = 2;                               % Количество генов (Переменных)

problem.VarMin = [0.1 0.0001];                      % Минимальные пределы переменных
problem.VarMax = [ 10  1];                        % Максимальные пределы переменных

%%  Параметры генетического алгоритма

params.MaxIt = 200;             % Максимальное количество итераций
params.nPop = 200;              % Количество особей

params.beta = 1.1;              % Коэффициент вероятности отбора
params.pC = 1;                  % Количество потомков
params.gamma = 0.025;           % Коффициент приращения при работе отбора
params.mu = 0.25;               % Скорость мутации
params.sigma = 0.25;            % Шаг для добавления к родителю при мутации

%% Запуск генетического алгоритма

out = RunGA(problem, params);


%%  Результаты

figure;

plot(out.bestcost, 'LineWidth', 2);
xlabel('Итерация');
ylabel('Лучшее значение');
grid on;
